import {ChangeDetectorRef, Component, OnInit} from '@angular/core';
import {ActivatedRoute, Router} from '@angular/router';
import {HttpClient} from '@angular/common/http';
import {FormsModule} from '@angular/forms';
import {NgForOf} from '@angular/common';
interface Question {
  text: string;
  options: string[];
  correctAnswer: string;
}
@Component({
  selector: 'app-quiz-create',
  imports: [
    FormsModule,
    NgForOf
  ],
  standalone:true,
  templateUrl: './quiz-create.html',
  styleUrl: './quiz-create.css',
})


export class QuizCreate implements OnInit {
  quiz: {
    jobId: number | null;
    passingScore: number;
    questions: Question[];
  } = {
    jobId: null,
    passingScore: 50,
    questions: []
  };

  constructor(
    private cdr: ChangeDetectorRef,
    private router: Router,
    private http: HttpClient,
    private route: ActivatedRoute
  ) {
  }
  ngOnInit() {
    const jobId = this.route.snapshot.paramMap.get('jobId');

    this.quiz.jobId = jobId ? +jobId : null;
  }

  addQuestion() {
    this.quiz.questions.push({
      text: '',
      options: ['', '', '', ''],
      correctAnswer: ''
    });
  }

  createQuiz() {

    const formattedQuestions = this.quiz.questions.map(q => ({
      questionText: q.text,
      optionA: q.options[0],
      optionB: q.options[1],
      optionC: q.options[2],
      optionD: q.options[3],
      correctAnswer: q.correctAnswer
    }));

    const payload = {
      jobId: this.quiz.jobId,
      passingScore: this.quiz.passingScore,
      questions: formattedQuestions
    };

    this.http.post('http://localhost:8027/recruiter/quiz', payload)
      .subscribe({
        next: () => alert("Quiz created!"),
        error: err => console.log(err)
      });
  
  }


}



