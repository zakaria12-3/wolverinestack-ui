import {ChangeDetectorRef, Component, OnInit} from '@angular/core';
import {JobService} from '../../../core/services/job.service';
import {CommonModule, NgFor} from '@angular/common';
import { HttpClient } from '@angular/common/http';
import {Router} from '@angular/router';
import {animate, style, transition, trigger} from '@angular/animations';
@Component({
  selector: 'app-candashboard',
  imports: [NgFor,CommonModule],
  templateUrl: './candashboard.html',
  standalone:true,
  styleUrl: './candashboard.css',
  animations: [
    trigger('fadeSlide', [
      transition(':enter', [
        style({ opacity: 0, transform: 'translateY(15px)' }),
        animate('650ms ease-out', style({ opacity: 1, transform: 'translateY(0)' }))
      ])
    ])
  ]
})
export class Candashboard implements OnInit{
  jobs: any[] = [];
  private dummyFile: any;



constructor(

  private router: Router,
  private http: HttpClient,
  private jobService: JobService,
  private cdr: ChangeDetectorRef
) {}

  ngOnInit() {

      this.loadJobs();

  }

  loadJobs() {
    this.http.get<any[]>('http://localhost:8027/candidate/jobs').subscribe(res => {
      this.jobs = res;
      this.cdr.detectChanges();
    });
  }
  selectedFile!: File;

  onFileSelected(event: any) {
    this.selectedFile = event.target.files[0];
  }
  apply(jobId: number) {
    const payload = {
      jobId: jobId,
      candidateId: Number(localStorage.getItem('userId')) // if you store it
    };

    console.log(payload);

    this.http.post('http://localhost:8027/candidate/apply', payload)
      .subscribe({
        next: () => alert("Applied!"),
        error: err => console.log("ERROR:", err.error)
      });
  }
}
