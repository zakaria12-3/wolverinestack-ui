import { Component } from '@angular/core';
import { HlmCardImports } from '@spartan-ng/helm/card';
import { HlmCarouselImports } from '@spartan-ng/helm/carousel';
import { provideIcons } from '@ng-icons/core';
import {lucideChevronDown, lucideLoader,lucideCheck} from '@ng-icons/lucide';
import { HlmInputImports } from '@spartan-ng/helm/input';
import Autoplay from 'embla-carousel-autoplay';
import { HlmButtonImports } from '@spartan-ng/helm/button';
import {HlmSpinnerImports} from '@spartan-ng/helm/spinner';
import {RouterLink} from '@angular/router';
import {animate, style, transition, trigger} from '@angular/animations';
@Component({
  selector: 'app-home',

  imports: [HlmCarouselImports, HlmButtonImports, HlmInputImports, HlmCardImports, HlmSpinnerImports, RouterLink],
  templateUrl: './home.html',
  styleUrl: './home.css',
  host: {
    class: 'contents',
  },
  providers: [provideIcons({ lucideLoader, lucideCheck,lucideChevronDown })],
  animations: [
    trigger('fadeSlide', [
      transition(':enter', [
        style({ opacity: 0, transform: 'translateY(15px)' }),
        animate('650ms ease-out', style({ opacity: 1, transform: 'translateY(0)' }))
      ])
    ])
  ],
  standalone:true,
})
export class Home {
  public items = [
    { image:'/assets/1.jpg',title:1},
    {image:'/assets/2.png',title:2},
    {image:'/assets/3.jpg',title:3},
  ];

  public plugins = [Autoplay({ delay: 3000 })];
}







