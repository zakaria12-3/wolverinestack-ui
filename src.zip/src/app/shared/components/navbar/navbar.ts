import {ChangeDetectionStrategy, ChangeDetectorRef, Component, OnInit} from '@angular/core';
import {HlmAvatarImports} from '@spartan-ng/helm/avatar';
import { RouterLink,Router} from '@angular/router';
import { hlmH3 } from '@spartan-ng/helm/typography';
import {animate, style, transition, trigger} from '@angular/animations';
import {NgIf} from '@angular/common';
import {AuthService} from '../../../core/services/auth.service';
@Component({
  selector: 'app-navbar',
  imports: [HlmAvatarImports, RouterLink, NgIf],
  animations: [
    trigger('fadeSlide', [
      transition(':enter', [
        style({ opacity: 0, transform: 'translateY(15px)' }),
        animate('650ms ease-out', style({ opacity: 1, transform: 'translateY(0)' }))
      ])
    ])
  ],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
      <div class="pl-4 pr-1 py-1">
          <div class="flex items-center justify-between mb-6" @fadeSlide>


              <div class="flex items-center space-x-6">

                  <hlm-avatar class="w-18 h-19 flex items-center">
                      <img hlmAvatarImage src="/recruitment-icon-6.png" routerLink="/" alt="logo"/>
                      <h2 class="${hlmH3}" routerLink="/">Step-Up Recruiting✅</h2>
                  </hlm-avatar>

                  &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
                  &nbsp;

                  <!-- Buttons -->
                  <div class="flex items-center space-x-3">
                      <button class="button" routerLink="/">
                          <svg class="icon" stroke="currentColor" fill="currentColor" viewBox="0 0 1024 1024">
                              <path d="M946.5 505L560.1 118.8l-25.9-25.9a31.5 31.5 0 0 0-44.4 0L77.5 505a63.9 63.9 0 0 0-18.8 46c.4 35.2 29.7 63.3 64.9 63.3h42.5V940h691.8V614.3h43.4c17.1 0 33.2-6.7 45.3-18.8a63.6 63.6 0 0 0 18.7-45.3c0-17-6.7-33.1-18.8-45.2zM568 868H456V664h112v204zm217.9-325.7V868H632V640c0-22.1-17.9-40-40-40H432c-22.1 0-40 17.9-40 40v228H238.1V542.3h-96l370-369.7 23.1 23.1L882 542.3h-96.1z"></path>
                          </svg>
                      </button>

                      <button class="button">
                          <svg class="icon" stroke="currentColor" fill="none" stroke-width="2" viewBox="0 0 24 24">
                              <path stroke-linecap="round" stroke-linejoin="round"
                                    d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"></path>
                          </svg>
                      </button>

                    <button class="button" *ngIf="!isUserLoggedIn">
                      <svg class="icon" stroke="currentColor" fill="currentColor" routerLink="/login" viewBox="0 0 24 24">
                        <path d="M12 2.5a5.5 5.5 0 0 1 3.096 10.047 9.005 9.005 0 0 1 5.9 8.181.75.75 0 1 1-1.499.044 7.5 7.5 0 0 0-14.993 0 .75.75 0 0 1-1.5-.045 9.005 9.005 0 0 1 5.9-8.18A5.5 5.5 0 0 1 12 2.5ZM8 8a4 4 0 1 0 8 0 4 4 0 0 0-8 0Z"></path>
                      </svg>
                    </button>
                    <div *ngIf="isUserLoggedIn" class="flex items-center space-x-3">

                      <button class="button" routerLink="/profile">
                        <svg class="icon" stroke="currentColor" fill="currentColor" viewBox="0 0 24 24">
                          <path d="M12 12a5 5 0 100-10 5 5 0 000 10zm0 2c-5.33 0-8 2.67-8 5v1h16v-1c0-2.33-2.67-5-8-5z"/>
                        </svg>
                      </button>

                      <button class="button" (click)="logout()">
                        <svg class="icon" stroke="currentColor" fill="none" stroke-width="2" viewBox="0 0 24 24">
                          <path stroke-linecap="round" stroke-linejoin="round"
                                d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1m0-10V5"></path>
                        </svg>
                      </button>

                    </div>


                  </div>
              </div>
          </div>
      </div>

  `,
  styleUrl: './navbar.css',
  standalone:true

})
export class Navbar implements  OnInit {

  isUserLoggedIn = false;

  constructor(
    private authService: AuthService,
    private router: Router,
    private cd: ChangeDetectorRef
  ) {}

  ngOnInit() {
    this.authService.isLoggedIn$.subscribe(status => {
      console.log("AUTH STATUS:", status); // 👈 DEBUG
      this.isUserLoggedIn = status;
      this.cd.detectChanges();
    });
  }

  logout() {
    this.authService.logout();
    this.router.navigate(['/login']);
  }

}
