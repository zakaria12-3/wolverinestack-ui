import { Component } from '@angular/core';
import { HlmCardImports } from '@spartan-ng/helm/card';
import { HlmCarouselImports } from '@spartan-ng/helm/carousel';
import { provideIcons } from '@ng-icons/core';
import {lucideChevronDown, lucideLoader,lucideCheck} from '@ng-icons/lucide';
import { HlmInputImports } from '@spartan-ng/helm/input';
import Autoplay from 'embla-carousel-autoplay';
import { HlmButtonImports } from '@spartan-ng/helm/button';
import {HlmSpinnerImports} from '@spartan-ng/helm/spinner';
import {Router, RouterLink} from '@angular/router';
import {animate, style, transition, trigger} from '@angular/animations';
import {HttpClient} from '@angular/common/http';
import {FormsModule} from '@angular/forms';
import {AuthService} from '../../core/services/auth.service';
@Component({
  selector: 'app-login',

  imports: [HlmCarouselImports, HlmButtonImports, HlmInputImports,FormsModule ,HlmCardImports, HlmSpinnerImports,RouterLink],
  templateUrl: './login.html',
  styleUrl: './login.css',
  host: {
    class: 'contents',
  },
  providers: [provideIcons({ lucideLoader, lucideCheck,lucideChevronDown })],
  animations: [
    trigger('fadeSlide', [
      transition(':enter', [
        style({ opacity: 0, transform: 'translateY(15px)' }),
        animate('650ms ease-out', style({ opacity: 1, transform: 'translateY(0)' }))
      ])
    ])
  ],
  standalone:true,
})
export class Login {
  public items = [
    { image:'/assets/1.jpg',title:1},
    {image:'/assets/2.png',title:2},
    {image:'/assets/3.jpg',title:3},
  ];

  public plugins = [Autoplay({ delay: 3000 })];
  constructor(private http: HttpClient, private router: Router , private authService: AuthService) {}
  credentials = {
    email: '',
    password: ''
  };
  onLogin(form: any) {
    if (!form.valid) return;

    const payload = {
      email: this.credentials.email.trim().toLowerCase(),
      password: this.credentials.password
    };

    this.http.post<any>('http://localhost:8027/auth/login', payload,{
      headers: { 'Content-Type': 'application/json' }})
      .subscribe({
        next: (res) => {
          console.log("RESPONSE:", res);

          if (!res || !res.token) {
            alert("No token received");
            return;
          }

          const token = res.token;

          if (!token.includes('.')) {
            alert("Invalid token format");
            return;
          }


          const decoded = JSON.parse(atob(token.split('.')[1]));
          let role = decoded.role.replace('ROLE_', '');

          localStorage.setItem('role', role);
          this.authService.login(token, role);

          this.router.navigate([`/${role.toLowerCase()}`]);
        },
        error: (err) => {
          console.log("ERROR RESPONSE:", err.error);
          alert(err.error || 'Login failed');
        }
      });
  }


}







