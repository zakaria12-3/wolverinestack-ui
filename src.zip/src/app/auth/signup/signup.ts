import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { trigger, transition, style, animate } from '@angular/animations';
import { Router, RouterLink } from '@angular/router';
import { HlmSkeletonImports } from '@spartan-ng/helm/skeleton';
import { HttpClient, HttpClientModule } from '@angular/common/http';

@Component({
  selector: 'app-signup',
  imports: [FormsModule, RouterLink, HlmSkeletonImports, HttpClientModule],
  templateUrl: './signup.html',
  styleUrls: ['./signup.css'],
  standalone: true,
  animations: [
    trigger('fadeSlide', [
      transition(':enter', [
        style({ opacity: 0, transform: 'translateY(15px)' }),
        animate('350ms ease-out', style({ opacity: 1, transform: 'translateY(0)' }))
      ])
    ])
  ]
})
export class Signup {

  constructor(private http: HttpClient, private router: Router) {}

  user = {
    username: '',
    email: '',
    password: '',
    confirmPassword: '',
    role: ''
  };

  onSubmit(form: any) {
    if (!form.valid) return;

    if (this.user.password !== this.user.confirmPassword) {
      alert('Passwords do not match');
      return;
    }
    const payload = {
      username: this.user.username,
      email: this.user.email.trim().toLowerCase(),
      password: this.user.password,
      role: 'CANDIDATE'
    };

    this.http.post('http://localhost:8027/auth/signup', payload)
      .subscribe({
        next: (response) => {
          console.log('Signup successful:', response);
          localStorage.setItem('verifyEmail', this.user.email);
          this.router.navigate(['/verify'],{
            queryParams: { email:  this.user.email}});
        },
        error: (err) => {
          console.error('Signup failed:', err);

          if (err.status === 400) {
            alert('User already exists or invalid data');
          } else {
            alert('Something went wrong');
          }
        }
      });
  }
}
