import { Routes } from '@angular/router';
import {Home} from './home/home';
import {Signup} from './auth/signup/signup';
import {Signupmain} from './signupmain/signupmain';
import {Signupcorp} from './auth/signupcorp/signupcorp';
import {Calendar} from './calendar/calendar';
import {Verify} from './auth/verify/verify';
import {Admindashboard} from './features/admin/admindashboard/admindashboard';
import {Candashboard} from './features/candidate/candashboard/candashboard';
import {Recdashboard} from './features/recruiter/recdashboard/recdashboard';
import {Login} from './auth/login/login';
import { QuizPass} from './features/candidate/quiz-pass/quiz-pass';
import {QuizResult} from './features/candidate/quizresult/quizresult';
import { authGuard } from './core/guards/auth.guard';
import { roleGuard } from './core/guards/role.guard';
import {JobCreate} from './features/recruiter/job-create/job-create';
import {QuizCreate} from './features/recruiter/quiz-create/quiz-create';
import {JobList} from './features/recruiter/job-list/job-list';

export const routes: Routes = [
  {
    path:'login',
    pathMatch: 'full',
    component:Login
  },
  {
    path:'',
    pathMatch: 'full',
    component:Home
  },
  {
    path:'quizpass',
    pathMatch: 'full',
    component:QuizPass,
    canActivate: [authGuard, roleGuard],
    data: { role: 'CANDIDATE' }
  },
  {
    path: 'quizpass/:id',
    loadComponent: () =>
      import('./features/candidate/quiz-pass/quiz-pass')
        .then(m => m.QuizPass),
    canActivate: [authGuard, roleGuard],
    data: { role: 'CANDIDATE' }
  },

  {
    path: 'quizresult/:jobId/:score',
    component: QuizResult,
    canActivate: [authGuard, roleGuard],
    data: { role: 'CANDIDATE' }
  },
  {
    path:'signupcand',
    pathMatch: 'full',
    component:Signup
  },
  {
    path:'signup',
    pathMatch: 'full',
    component:Signupmain
  },
  {
    path:'signup/company',
    pathMatch: 'full',
    component:Signupcorp
  },
  {
    path:'calendar',
    pathMatch: 'full',
    component:Calendar
  },
  {
    path:'verify',
    pathMatch:'full',
    component:Verify

  },
  {
    path:'admin',
    pathMatch: 'full',
    component:Admindashboard,
    canActivate: [authGuard, roleGuard],
    data: { role: 'ADMIN' }
  },
  {
    path: 'recruiter/job/:id',
    component: JobList,
    pathMatch: 'full',
    canActivate: [authGuard, roleGuard],
    data: { role: 'RECRUITER' }
  },
  {
    path:'candidate',
    pathMatch: 'full',
    component:Candashboard,
    canActivate: [authGuard, roleGuard],
    data: { role: 'CANDIDATE' }
  },
  {
    path:'recruiter',
    pathMatch: 'full',
    component:Recdashboard,
    canActivate: [authGuard, roleGuard],
    data: { role: 'RECRUITER' }
  },
  {
    path:'job-create',
    pathMatch: 'full',
    component:JobCreate,
    canActivate: [authGuard, roleGuard],
    data: { role: 'RECRUITER' }
  },
  {
    path:'quiz-create/:jobId',
    pathMatch: 'full',
    component:QuizCreate,
    canActivate: [authGuard, roleGuard],
    data: { role: 'RECRUITER' }
  },
  { path: '**', redirectTo: '' }

];
