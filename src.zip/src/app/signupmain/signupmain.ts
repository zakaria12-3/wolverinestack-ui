import { Component ,ChangeDetectionStrategy} from '@angular/core';
import {HlmCardImports} from '@spartan-ng/helm/card';
import {HlmButtonImports} from '@spartan-ng/helm/button';
import {HlmBadgeImports} from '@spartan-ng/helm/badge';
import {provideIcons} from '@ng-icons/core';
import {lucideCheck, lucideChevronDown, lucideLoader} from '@ng-icons/lucide';
import {animate, style, transition, trigger} from '@angular/animations';
import {RouterLink} from '@angular/router';

@Component({
  selector: 'app-signupmain',
  imports: [HlmCardImports, HlmButtonImports, HlmBadgeImports, RouterLink],
  templateUrl: './signupmain.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
  standalone:true,
  providers: [provideIcons({ lucideLoader, lucideCheck,lucideChevronDown })],
  animations: [
    trigger('fadeSlide', [
      transition(':enter', [
        style({ opacity: 0, transform: 'translateY(15px)' }),
        animate('650ms ease-out', style({ opacity: 1, transform: 'translateY(0)' }))
      ])
    ])
  ],
  styleUrl: './signupmain.css',
})
export class Signupmain {

}
